require 'test_helper'

class UserStocksControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
